"""Re-test published 142 candidate links from the user-supplied MaDI audit with current VMARO rules.
Does NOT estimate recall/precision on full MaDI test sets.
"""
import csv,json,collections,sys,hashlib
from pathlib import Path
sys.path.insert(0,'/mnt/data/vmaro_review/VMARO-main')
from utils.multi_api_fetcher import MultiAPIFetcher
from scripts.madi_fuzzy_grouping import part_conflict,affirmative_evidence_view
p=Path('/mnt/data/vmaro_review/VMARO-main/docs/evaluation/madi-unlabelled-link-audit.csv')
rows=list(csv.DictReader(p.open()))
matcher=MultiAPIFetcher()
counts=collections.Counter(); examples=[]; contradictions=[]
for x in rows:
    def record(side):
        return dict(title=x[f'{side}_title'],authors=json.loads(x[f'{side}_authors']),doi='',source=('dblp' if x[f'{side}_id'].startswith('dblp-') else 'crossref' if x[f'{side}_id'].startswith('crossref-') else 'open_alex'))
    a=record('left');b=record('right')
    linked=len(matcher._deduplicate([a,b]))==1
    number_conflict=part_conflict(a['title'],b['title'])
    x['production_pair_match']=int(linked);x['numbered_part_veto']=int(number_conflict)
    counts[(x['assessment'],bool(linked),bool(number_conflict))]+=1
    if linked and x['assessment']=='publisher-confirmed false merge': contradictions.append(x['id'])
    if x['assessment']=='publisher-confirmed false merge':examples.append({k:x[k] for k in ('id','left_id','right_id','left_title','right_title','assessment','production_pair_match','numbered_part_veto')})
print('Source audit sha256',hashlib.sha256(p.read_bytes()).hexdigest())
print('Source assessment counts',dict(collections.Counter(x['assessment'] for x in rows)))
print('Paired matcher results:')
for key,n in sorted(counts.items()):print(key,n)
print('Confirmed incorrect cases',json.dumps(examples,indent=2))
print('Matcher linking confirmed incorrect',contradictions)
Path('/mnt/data/vmaro_work/madi_audit_pairwise_check.json').write_text(json.dumps({'assessments':dict(collections.Counter(x['assessment'] for x in rows)),'breakdown':[{'assessment':k[0],'production_pair_match':k[1],'numbered_part_veto':k[2],'n':v} for k,v in sorted(counts.items())],'confirmed_cases':examples},indent=2)+'\n')
