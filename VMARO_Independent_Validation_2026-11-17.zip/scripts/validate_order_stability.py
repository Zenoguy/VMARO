from pathlib import Path
import itertools,random,csv,sys,collections,json
sys.path.insert(0,'/mnt/data/vmaro_review/VMARO-main')
from utils.multi_api_fetcher import MultiAPIFetcher
matcher=MultiAPIFetcher();src=Path('/mnt/data/VMARO_12_Page_Revised_Overleaf/reproduction/data/records.csv')
rows=list(csv.DictReader(src.open()))
result={}
for mode in ('venue_doi_only','both_dois'):
    records=[dict(id=x['record_id'],title=x['title'],authors=[x['first_author']],doi=x['venue_doi'] or (x['arxiv_doi'] if mode=='both_dois' else ''),source='CrossRef' if x['source']=='ACL Anthology' else 'arXiv') for x in rows]
    patterns=collections.Counter();r=random.Random(12345)
    for trial in range(1000):
       seq=records.copy();r.shuffle(seq)
       groups=matcher._deduplicate(seq)
       pairs=frozenset(tuple(sorted((a,b))) for g in groups for a,b in itertools.combinations([g['id']]+[x['id'] for x in g.get('duplicate_records',[])],2))
       patterns[pairs]+=1
    result[mode]={'distinct_pair_patterns':len(patterns),'group_count_patterns':sorted(set(len(p) for p in patterns)),'pattern_frequencies':sorted(patterns.values(),reverse=True)[:3]}
print(json.dumps(result,indent=2));Path('/mnt/data/vmaro_work/order_stability.json').write_text(json.dumps(result,indent=2))
