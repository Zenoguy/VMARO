"""Offline independent replay: new VMARO matcher on paper's fixed ACL/arXiv ground truth."""
import csv, itertools, json, random, statistics, hashlib, sys
from pathlib import Path
sys.path.insert(0,'/mnt/data/vmaro_review/VMARO-main')
from utils.multi_api_fetcher import MultiAPIFetcher
repo=Path('/mnt/data/vmaro_review/VMARO-main')
csvpath=Path('/mnt/data/VMARO_12_Page_Revised_Overleaf/reproduction/data/records.csv')
rows=list(csv.DictReader(csvpath.open()))
assert len(rows)==50 and len(set(r['work_id'] for r in rows))==26
assert sum(a['source']!=b['source'] and a['work_id']==b['work_id'] for a,b in itertools.combinations(rows,2))==24
matcher=MultiAPIFetcher()

def adapt(r,mode):
    doi=r['venue_doi'] or (r['arxiv_doi'] if mode=='both_dois' else '')
    return {'id':r['record_id'],'work_id':r['work_id'],'title':r['title'],'authors':[r['first_author']] if r['first_author'] else [], 'doi':doi,'source':('CrossRef' if r['source']=='ACL Anthology' else r['source']),'url':r['url']}

def pairset(recs):
    groups=matcher._deduplicate(recs)
    pred=set()
    for p in groups:
        ids=[p['id']]+[s['id'] for s in p.get('duplicate_records',[])]
        pred|={tuple(sorted(t)) for t in itertools.combinations(ids,2)}
    return groups,pred

out={'provenance': {'source_snapshot':'VMARO-main (1).zip uploaded 2026-11-17','matcher_sha256':hashlib.sha256((repo/'utils/multi_api_fetcher.py').read_bytes()).hexdigest(),'archive_records_sha256':hashlib.sha256(csvpath.read_bytes()).hexdigest(),'script':'validate_new_matcher.py'}, 'modes':{}}
for mode in ['venue_doi_only','both_dois']:
    records=[adapt(r,mode) for r in rows]
    gold={tuple(sorted((a['id'],b['id']))) for a,b in itertools.combinations(records,2) if a['work_id']==b['work_id']}
    cross={tuple(sorted((a['id'],b['id']))) for a,b in itertools.combinations(records,2) if a['source']!=b['source']}
    assert len(gold)==24 and len(cross)==624
    g,pred=pairset(records)
    tp=len(pred & gold);fp=len(pred - gold);fn=len(gold-pred)
    # Pair-by-pair independent from the whole-pool grouping: detects chaining effects.
    directpred={tuple(sorted((a['id'],b['id']))) for a,b in itertools.combinations(records,2) if len(matcher._deduplicate([a,b]))==1}
    assert pred<=directpred
    rng=random.Random(20261116)
    caps={5:[],10:[],20:[]}; redundant={5:0,10:0,20:0}
    for i in range(1000):
        shuffled=records.copy();rng.shuffle(shuffled)
        grouped,_=pairset(shuffled)
        for cap in caps:
            selected=grouped[:cap]
            distinct=len(set(x['work_id'] for x in selected));caps[cap].append(distinct)
            if distinct<cap:redundant[cap]+=1
    data={'records':len(records),'true_works':26,'positive_pairs':len(gold),'all_cross_source_pairs':len(cross),
          'pairwise':{'tp':tp,'fp':fp,'fn':fn,'precision':tp/max(tp+fp,1),'recall':tp/max(tp+fn,1),'f1':2*tp/max(2*tp+fp+fn,1)},
          'result_groups':len(g),'redundant_records_remaining':len(g)-26,'pair_direct':len(directpred),'pair_grouped':len(pred),
          'missed_pairs':sorted(list(gold-pred)),
          'cap':{str(cap):{'mean_distinct':statistics.mean(vals),'min':min(vals),'max':max(vals),'runs_with_redundancy':redundant[cap]} for cap,vals in caps.items()}}
    out['modes'][mode]=data
print(json.dumps(out,indent=2))
Path('/mnt/data/vmaro_work/new_matcher_acl_results.json').write_text(json.dumps(out,indent=2)+'\n')
