import streamlit as st
import json
import time
from main import run_pipeline
from utils.cache import CACHE_DIR
import os

st.set_page_config(page_title="VMARO Pipeline", layout="wide")

st.title("VMARO Research Orchestrator")
st.markdown("Enter a research topic to generate a full grant proposal pipeline.")

with st.sidebar:
    st.header("Input Section")
    topic = st.text_input("Research Topic", "Federated Learning in Healthcare")
    run_btn = st.button("▶ Run Analysis")

if run_btn:
    # Clear cache before new run
    if os.path.exists(CACHE_DIR):
        import shutil
        shutil.rmtree(CACHE_DIR)
        
    with st.spinner(f"Running full orchestrator pipeline for '{topic}'... (This may take ~10 minutes on free-tier)"):
        results = run_pipeline(topic)
        st.success("Pipeline completed!")

    tabs = st.tabs([
        "📚 Literature", 
        "📊 Tree Index", 
        "📈 Trends & Gaps", 
        "🧪 Methodology", 
        "📝 Grant Proposal", 
        "⭐ Novelty Score"
    ])

    with tabs[0]:
        st.header("Section 1 - Retrieved Literature")
        papers = results.get("papers", {})
        for p in papers.get("papers", []):
            with st.container():
                st.subheader(p.get('title', 'Unknown Title'))
                st.write(f"**Year:** {p.get('year', 'N/A')}")
                st.write(f"**Summary:** {p.get('summary', 'N/A')}")
                st.write(f"**Contribution:** {p.get('contribution', 'N/A')}")
                st.markdown(f"**Source:** [{p.get('source', '')}]({p.get('source', '')})")
                st.divider()

    with tabs[1]:
        st.header("Section 2 - Thematic Tree Index")
        tree = results.get("tree", {})
        st.subheader(f"Root: {tree.get('root', 'Unknown')}")
        
        for theme in tree.get("themes", []):
            with st.expander(f"{theme.get('theme_id')}: {theme.get('theme_name')}"):
                for idx, p in enumerate(theme.get('papers', [])):
                    st.write(f"{idx+1}. {p.get('title')}")
                    
        st.subheader("Emerging Directions")
        for d in tree.get("emerging_directions", []):
            st.markdown(f"- {d}")

    with tabs[2]:
        st.header("Section 3 - Trends & Gaps")
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("Trends")
            trends = results.get("trends", {})
            st.write("**Dominant Clusters:**")
            for c in trends.get("dominant_clusters", []):
                st.markdown(f"- {c}")
            st.write("**Emerging Trends:**")
            for t in trends.get("emerging_trends", []):
                st.markdown(f"- {t}")
                
        with col2:
            st.subheader("Identified Gaps")
            gaps = results.get("gaps", {})
            for g in gaps.get("identified_gaps", []):
                with st.container(border=True):
                    st.write(f"**ID:** {g.get('gap_id')}")
                    st.write(f"**Description:** {g.get('description')}")
                    st.write(f"**Why Underexplored:** {g.get('why_underexplored')}")
            st.info(f"**Selected Gap:** {gaps.get('selected_gap')}")

    with tabs[3]:
        st.header("Section 4 - Experimental Methodology")
        meth = results.get("methodology", {})
        
        c1, c2, c3 = st.columns(3)
        with c1:
            st.write("**Datasets:**")
            for d in meth.get("suggested_datasets", []):
                st.markdown(f"- {d}")
        with c2:
            st.write("**Metrics:**")
            for m in meth.get("evaluation_metrics", []):
                st.markdown(f"- {m}")
        with c3:
            st.write("**Baselines:**")
            for b in meth.get("baseline_models", []):
                st.markdown(f"- {b}")
                
        st.subheader("Experimental Design")
        st.write(meth.get("experimental_design", ""))
        
        st.subheader("Tools & Frameworks")
        st.write(", ".join(meth.get("tools_and_frameworks", [])))

    with tabs[4]:
        st.header("Section 5 - Grant Proposal")
        grant = results.get("grant", {})
        
        st.markdown(f"### Problem Statement\n{grant.get('problem_statement', '')}")
        st.markdown(f"### Proposed Methodology\n{grant.get('proposed_methodology', '')}")
        st.markdown(f"### Evaluation Plan\n{grant.get('evaluation_plan', '')}")
        st.markdown(f"### Expected Contribution\n{grant.get('expected_contribution', '')}")
        st.markdown(f"### Timeline\n{grant.get('timeline', '')}")
        st.markdown(f"### Budget Estimate\n{grant.get('budget_estimate', '')}")
        
        st.download_button(
            label="Download Proposal JSON",
            data=json.dumps(grant, indent=2),
            file_name=f"{topic.replace(' ', '_').lower()}_grant.json",
            mime="application/json"
        )

    with tabs[5]:
        st.header("Section 6 - Novelty Score")
        nov = results.get("novelty", {})
        
        score = nov.get("novelty_score", 0)
        
        # Color coding logic
        if score < 40:
            color, emoji = "red", "🔴"
        elif score < 70:
            color, orange = "orange", "🟡"
        else:
            color, emoji = "green", "🟢"
            
        st.metric("Novelty Score", f"{score} / 100")
        st.markdown(f"## {emoji} Indicator")
        
        st.subheader("Justification")
        st.write(nov.get("score_justification", ""))
        
        st.subheader("Similarity Reasoning")
        st.write(nov.get("similarity_reasoning", ""))
        
        st.subheader("Closest Papers")
        for p in nov.get("closest_papers", []):
            st.markdown(f"- {p}")
