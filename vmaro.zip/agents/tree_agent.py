import os
import json
from google import genai
from utils.schema import get_api_key, safe_parse

def run(papers: dict) -> dict:
    print("[TreeBuilder]  Building thematic tree")
    
    # MOCK_MODE check isn't strictly requested for all agents at the top of run(),
    # but the prompt says literature_agent uses mock_mode flag, others might just rely on tests passing mock dicts.
    # We will enforce schema parsing and fallback.
    
    fallback = {
        "root": papers.get("topic", "Unknown Topic"),
        "themes": [],
        "emerging_directions": []
    }

    try:
        prompt = f"""You are a research taxonomist. Given these papers on "{papers.get("topic")}", cluster them into
3–5 high-level themes. Identify emerging directions not covered by existing papers.

Papers: {json.dumps(papers)}

Return ONLY valid JSON:
{{
  "root": "{papers.get("topic")}",
  "themes": [
    {{ "theme_id": "T1", "theme_name": "...", "papers": [...paper objects...] }}
  ],
  "emerging_directions": ["...", "..."]
}}
No extra text. JSON only."""

        client = genai.Client(api_key=get_api_key())
        
        for attempt in range(2):
            try:
                response = client.models.generate_content(
                    model="gemini-2.0-flash",
                    contents=prompt if attempt == 0 else prompt + "\nProvide ONLY valid JSON."
                )
                return safe_parse(response.text)
            except Exception as e:
                if attempt == 1:
                    print(f"TreeBuilder Gemini failed: {e}")
                    raise

    except Exception as e:
        print(f"TreeBuilder failed: {e}")
        return fallback
