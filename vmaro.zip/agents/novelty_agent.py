import json
from google import genai
from utils.schema import get_api_key, safe_parse

def run(grant: dict, tree: dict) -> dict:
    print("[Agent6]       Novelty Scoring")
    
    fallback = {
        "closest_papers": [],
        "similarity_reasoning": "Failed to generate novelty score.",
        "novelty_score": 0,
        "score_justification": ""
    }

    try:
        client = genai.Client(api_key=get_api_key())

        # Step 1 — Theme Navigation
        theme_names_and_ids = [
            {"theme_id": t.get("theme_id"), "theme_name": t.get("theme_name")} 
            for t in tree.get("themes", [])
        ]
        
        prompt_step1 = f"""You are a research evaluator. Given this proposal and a list of research themes,
identify which themes are most related.

Proposal Summary: {grant.get("problem_statement", "")}
Available Themes: {json.dumps(theme_names_and_ids)}

Return ONLY valid JSON:
{{
  "selected_theme_ids": ["T1", "T3"],
  "reasoning": "why these themes are most relevant"
}}
No extra text. JSON only."""

        step1_result = None
        for attempt in range(2):
            try:
                response = client.models.generate_content(
                    model="gemini-2.0-flash",
                    contents=prompt_step1 if attempt == 0 else prompt_step1 + "\nProvide ONLY valid JSON."
                )
                step1_result = safe_parse(response.text)
                break
            except Exception as e:
                if attempt == 1:
                    print(f"Agent6 Step 1 Gemini failed: {e}")
                    raise
                    
        if not step1_result:
            raise ValueError("Step 1 failed to return parsed JSON")

        selected_theme_ids = step1_result.get("selected_theme_ids", [])
        
        # Step 2 — Paper-level scoring
        filtered_papers = []
        for t in tree.get("themes", []):
            if t.get("theme_id") in selected_theme_ids:
                filtered_papers.extend(t.get("papers", []))
                
        # Cap at 5 papers max
        filtered_papers = filtered_papers[:5]

        prompt_step2 = f"""You are an expert peer reviewer assessing research novelty.

Proposal: {json.dumps(grant)}
Related Papers (selected themes only): {json.dumps(filtered_papers)}

Evaluate:
1. Which papers does this most closely resemble?
2. What makes this proposal meaningfully different?
3. Rate novelty 0 (fully replicated) to 100 (completely novel)

Return ONLY valid JSON:
{{
  "closest_papers": ["Paper Title A", "Paper Title B"],
  "similarity_reasoning": "specific similarities found",
  "novelty_score": 78,
  "score_justification": "why this score was given"
}}
No extra text. JSON only."""

        for attempt in range(2):
            try:
                response = client.models.generate_content(
                    model="gemini-2.0-flash",
                    contents=prompt_step2 if attempt == 0 else prompt_step2 + "\nProvide ONLY valid JSON."
                )
                return safe_parse(response.text)
            except Exception as e:
                if attempt == 1:
                    print(f"Agent6 Step 2 Gemini failed: {e}")
                    raise

    except Exception as e:
        print(f"Agent6 failed: {e}")
        return fallback
