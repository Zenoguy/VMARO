import json
from google import genai
from utils.schema import get_api_key, safe_parse

def run(topic: str, gap_description: str, methodology: dict) -> dict:
    print("[Agent5]       Grant Writing")
    
    fallback = {
        "problem_statement": "Failed to generate grant proposal.",
        "proposed_methodology": "",
        "evaluation_plan": "",
        "expected_contribution": "",
        "timeline": "",
        "budget_estimate": ""
    }

    try:
        prompt = f"""You are a grant proposal writer. Using the identified research gap and proposed
methodology, generate a complete funding-ready grant proposal.

Research Topic: {topic}
Research Gap: {gap_description}
Methodology: {json.dumps(methodology)}

Return ONLY valid JSON:
{{
  "problem_statement": "2-3 paragraph problem description",
  "proposed_methodology": "detailed approach referencing the methodology",
  "evaluation_plan": "how results will be measured",
  "expected_contribution": "impact and novelty",
  "timeline": "phased 6-month plan",
  "budget_estimate": "cost breakdown with justification"
}}
No extra text. JSON only."""

        client = genai.Client(api_key=get_api_key())
        
        for attempt in range(2):
            try:
                response = client.models.generate_content(
                    model="gemini-2.0-flash",
                    contents=prompt if attempt == 0 else prompt + "\nProvide ONLY valid JSON."
                )
                return safe_parse(response.text)
            except Exception as e:
                if attempt == 1:
                    print(f"Agent5 Gemini failed: {e}")
                    raise

    except Exception as e:
        print(f"Agent5 failed: {e}")
        return fallback
