import json
from google import genai
from utils.schema import get_api_key, safe_parse

def run(tree: dict, trends: dict) -> dict:
    print("[Agent3]       Gap Identification")
    
    fallback = {
        "identified_gaps": [],
        "selected_gap": ""
    }

    try:
        prompt = f"""You are a research gap analyst. Given this research tree and identified trends, find
underexplored intersections that represent meaningful research gaps.

Tree: {json.dumps(tree)}
Identified Trends: {json.dumps(trends)}

Return ONLY valid JSON:
{{
  "identified_gaps": [
    {{ "gap_id": "G1", "description": "...", "why_underexplored": "..." }}
  ],
  "selected_gap": "G1"
}}
No extra text. JSON only."""

        client = genai.Client(api_key=get_api_key())
        
        for attempt in range(2):
            try:
                response = client.models.generate_content(
                    model="gemini-2.0-flash",
                    contents=prompt if attempt == 0 else prompt + "\nProvide ONLY valid JSON."
                )
                return safe_parse(response.text)
            except Exception as e:
                if attempt == 1:
                    print(f"Agent3 Gemini failed: {e}")
                    raise

    except Exception as e:
        print(f"Agent3 failed: {e}")
        return fallback
