import json
from google import genai
from utils.schema import get_api_key, safe_parse

def run(gap_description: str, topic: str) -> dict:
    print("[Agent4]       Methodology Design")
    
    fallback = {
        "suggested_datasets": [],
        "evaluation_metrics": [],
        "baseline_models": [],
        "experimental_design": "Failed to generate methodology.",
        "tools_and_frameworks": []
    }

    try:
        prompt = f"""You are a research methodology expert. Given this research gap, recommend a concrete
experimental methodology.

Research Gap: {gap_description}
Research Topic: {topic}

Return ONLY valid JSON:
{{
  "suggested_datasets": ["dataset1", "dataset2"],
  "evaluation_metrics": ["metric1", "metric2"],
  "baseline_models": ["baseline1", "baseline2"],
  "experimental_design": "step-by-step methodology",
  "tools_and_frameworks": ["tool1", "tool2"]
}}
No extra text. JSON only."""

        client = genai.Client(api_key=get_api_key())
        
        for attempt in range(2):
            try:
                response = client.models.generate_content(
                    model="gemini-2.0-flash",
                    contents=prompt if attempt == 0 else prompt + "\nProvide ONLY valid JSON."
                )
                return safe_parse(response.text)
            except Exception as e:
                if attempt == 1:
                    print(f"Agent4 Gemini failed: {e}")
                    raise

    except Exception as e:
        print(f"Agent4 failed: {e}")
        return fallback
