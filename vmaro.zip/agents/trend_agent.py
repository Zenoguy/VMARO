import json
from google import genai
from utils.schema import get_api_key, safe_parse

def run(tree: dict) -> dict:
    print("[Agent2]       Trend Analysis")
    
    fallback = {
        "dominant_clusters": [],
        "emerging_trends": []
    }

    try:
        prompt = f"""You are a research trend analyst. Analyze this hierarchical research tree and identify
dominant research clusters and emerging directions.

Tree: {json.dumps(tree)}

Return ONLY valid JSON:
{{
  "dominant_clusters": ["cluster 1", "cluster 2"],
  "emerging_trends": ["trend 1", "trend 2"]
}}
No extra text. JSON only."""

        client = genai.Client(api_key=get_api_key())
        
        for attempt in range(2):
            try:
                response = client.models.generate_content(
                    model="gemini-2.0-flash",
                    contents=prompt if attempt == 0 else prompt + "\nProvide ONLY valid JSON."
                )
                return safe_parse(response.text)
            except Exception as e:
                if attempt == 1:
                    print(f"Agent2 Gemini failed: {e}")
                    raise

    except Exception as e:
        print(f"Agent2 failed: {e}")
        return fallback
